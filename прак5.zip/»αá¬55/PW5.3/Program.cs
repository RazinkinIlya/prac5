﻿DigitFilter FilterNumbers = new DigitFilter();
LetterFilter FilterLetter = new LetterFilter();
string textLine = "1dsa1dsad321asd2as dsada3213sdasd dsa5565dasad";
FilterNumbers.Execute(textLine);
FilterLetter.Execute(textLine);
Console.WriteLine(FilterNumbers.newText); 
Console.WriteLine($" \n\n{FilterLetter.newText}"); 




interface IFilter
{

    string Execute(string textLine);
}

class DigitFilter : IFilter
{

    public string newText;
    private int j;






    public string Execute(string textLine) 
                
    {
             char[] textToArray = textLine.ToCharArray();
            char[] numbers = { '1','2', '3', '4', '5', '6', '7', '8', '9', '0' };
        for (int i = 0; i < textToArray.Length; i++)
        {
            for ( j = 0; j < numbers.Length; j++)
            {
                if(textToArray[i] == numbers[j])
                {
                    textToArray[i] = '*';
                    break;
                }

            }
            

        }

        newText = new string(textToArray);
        newText = newText.Replace("*", "");
        return newText;
    }


}

class LetterFilter : IFilter
{
    public string newText;
    private int j;
    private char[] alphabetRu = "абвгдеёжзийклмнопрстуфхцчшщъыьэюяabcdefghijklmnopqrstuvwxyz".ToCharArray();
    public string Execute(string textLine) 
    {
        textLine = textLine.ToLower();
        char[] textToArray = textLine.ToCharArray();
        for (int i = 0; i < textToArray.Length; i++)
        {
            for (j = 0; j < alphabetRu.Length; j++)
            {
                if (textToArray[i] == alphabetRu[j])
                {
                    textToArray[i] = '*';
                    break;
                }

            }


        }


        newText = new string(textToArray);
        newText = newText.Replace("*", "");
        return newText;
    }

}