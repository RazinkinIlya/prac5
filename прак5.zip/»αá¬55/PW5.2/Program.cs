﻿
List<IHello> hello = new List<IHello>();
hello.Add(new HelloOnRu());
hello.Add(new HelloOnEn());
hello.Add(new HelloOnFr());
hello.Add(new HelloOnEsp());
hello.Add(new HelloOnBg());

foreach (IHello helloDiffLanguage in hello) 
{
    helloDiffLanguage.SayHello();
}

Console.ReadKey(true);




interface IHello
{
    void SayHello();

}


class HelloOnRu : IHello
{
    public void SayHello()
    {
        Console.WriteLine("Привет");
    }
}
class HelloOnEn : IHello
{
    public void SayHello()
    {
        Console.WriteLine("hello");
    }
}
class HelloOnFr : IHello
{
    public void SayHello()
    {
        Console.WriteLine("Bonjour");
    }
}
class HelloOnEsp : IHello
{
    public void SayHello()
    {
        Console.WriteLine("Hola");
    }
}
class HelloOnBg : IHello
{
    public void SayHello()
    {
        Console.WriteLine("Здравейте");
    }
}
